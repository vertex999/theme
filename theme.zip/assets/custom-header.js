document.addEventListener('DOMContentLoaded', function() {
  console.log('Custom header script loaded');
  
  const CustomHeaderWrapper = document.getElementById('Custom-header-wrapper');
  
  // Scroll behavior for sticky header
  if (CustomHeaderWrapper) {
    console.log('Sticky header enabled:', CustomHeaderWrapper.getAttribute('data-Custom-sticky'));
    console.log('Hide on scroll enabled:', CustomHeaderWrapper.getAttribute('data-Custom-hide-on-scroll'));
    
    if (CustomHeaderWrapper.getAttribute('data-Custom-sticky') === 'true') {
      console.log('Sticky header is active');
      
      let lastScrollTop = 0;
      const scrollThreshold = 200;
      
      window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        console.log('Scrolling, current position:', scrollTop);
        
        if (CustomHeaderWrapper.getAttribute('data-Custom-hide-on-scroll') === 'true') {
          console.log('Hide on scroll is active');
          
          // Hide on scroll down, show on scroll up
          if (scrollTop > lastScrollTop && scrollTop > scrollThreshold) {
            // Scrolling down
            console.log('Scrolling down, hiding header');
            CustomHeaderWrapper.style.transform = 'translateY(-100%)';
          } else {
            // Scrolling up
            console.log('Scrolling up, showing header');
            CustomHeaderWrapper.style.transform = 'translateY(0)';
          }
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      }, { passive: true });
    }
  }
  
  // Dropdown menus handling
  const CustomMenuItems = document.querySelectorAll('.Custom-header__menu-item');
  const CustomDropdownMode = CustomHeaderWrapper ? CustomHeaderWrapper.getAttribute('data-Custom-dropdown-mode') : 'hover';
  
  CustomMenuItems.forEach(item => {
    const details = item.querySelector('details');
    
    if (details) {
      // Check if we're on a touch device
      const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      
      if (CustomDropdownMode === 'hover' && !isTouchDevice) {
        // Hover mode for non-touch devices
        let timeout;
        
        item.addEventListener('mouseenter', () => {
          clearTimeout(timeout);
          details.setAttribute('open', true);
        });
        
        item.addEventListener('mouseleave', () => {
          timeout = setTimeout(() => {
            details.removeAttribute('open');
          }, 150);
        });
      } else {
        // Click mode for touch devices or when explicitly set
        const summary = details.querySelector('summary');
        
        summary.addEventListener('click', (e) => {
          // Prevent the default toggle behavior
          e.preventDefault();
          
          // Close all other open dropdowns
          CustomMenuItems.forEach(otherItem => {
            const otherDetails = otherItem.querySelector('details');
            if (otherDetails && otherDetails !== details && otherDetails.hasAttribute('open')) {
              otherDetails.removeAttribute('open');
            }
          });
          
          // Toggle the current dropdown
          if (details.hasAttribute('open')) {
            details.removeAttribute('open');
          } else {
            details.setAttribute('open', true);
          }
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
          if (!item.contains(e.target) && details.hasAttribute('open')) {
            details.removeAttribute('open');
          }
        });
      }
    }
  });
  
  // Search bar functionality
  const CustomSearchToggle = document.getElementById('Custom-search-toggle');
  const CustomSearchBar = document.getElementById('Custom-search-bar');
  const CustomSearchClose = document.getElementById('Custom-search-close');
  
  if (CustomSearchToggle && CustomSearchBar) {
    CustomSearchToggle.addEventListener('click', function(e) {
      e.preventDefault();
      CustomSearchBar.classList.toggle('Custom-active');
      CustomSearchToggle.setAttribute('aria-expanded', CustomSearchBar.classList.contains('Custom-active'));
      
      if (CustomSearchBar.classList.contains('Custom-active')) {
        setTimeout(() => {
          const searchInput = CustomSearchBar.querySelector('.Custom-search-bar__input');
          if (searchInput) searchInput.focus();
        }, 100);
      }
    });
    
    if (CustomSearchClose) {
      CustomSearchClose.addEventListener('click', function() {
        CustomSearchBar.classList.remove('Custom-active');
        CustomSearchToggle.setAttribute('aria-expanded', 'false');
      });
    }
    
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && CustomSearchBar.classList.contains('Custom-active')) {
        CustomSearchBar.classList.remove('Custom-active');
        CustomSearchToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }
  
  // Mobile sidebar menu
  const CustomDrawerButton = document.querySelector('.Custom-header__drawer-button button');
  const CustomSidebar = document.getElementById('Custom-sidebar');
  const CustomSidebarClose = document.getElementById('Custom-sidebar-close');
  const CustomSidebarOverlay = document.getElementById('Custom-sidebar-overlay');
  
  if (CustomDrawerButton && CustomSidebar) {
    CustomDrawerButton.addEventListener('click', function() {
      CustomSidebar.classList.add('Custom-active');
      CustomSidebarOverlay.classList.add('Custom-active');
      document.body.style.overflow = 'hidden';
    });
    
    if (CustomSidebarClose) {
      CustomSidebarClose.addEventListener('click', function() {
        CustomSidebar.classList.remove('Custom-active');
        CustomSidebarOverlay.classList.remove('Custom-active');
        document.body.style.overflow = '';
      });
    }
    
    if (CustomSidebarOverlay) {
      CustomSidebarOverlay.addEventListener('click', function() {
        CustomSidebar.classList.remove('Custom-active');
        CustomSidebarOverlay.classList.remove('Custom-active');
        document.body.style.overflow = '';
      });
    }
  }
  
  // Language and country selectors
  const CustomLanguageSelector = document.querySelector('.Custom-language-selector');
  const CustomCountrySelector = document.querySelector('.Custom-country-selector');
  
  if (CustomLanguageSelector) {
    const languageButton = CustomLanguageSelector.querySelector('button');
    const languageList = CustomLanguageSelector.querySelector('ul');
    
    if (languageButton && languageList) {
      languageButton.addEventListener('click', () => {
        const isExpanded = languageButton.getAttribute('aria-expanded') === 'true';
        languageButton.setAttribute('aria-expanded', !isExpanded);
        languageList.classList.toggle('Custom-active');
      });
      
      // Close when clicking outside
      document.addEventListener('click', (e) => {
        if (!CustomLanguageSelector.contains(e.target) && languageList.classList.contains('Custom-active')) {
          languageButton.setAttribute('aria-expanded', 'false');
          languageList.classList.remove('Custom-active');
        }
      });
    }
  }
  
  if (CustomCountrySelector) {
    const countryButton = CustomCountrySelector.querySelector('button');
    const countryList = CustomCountrySelector.querySelector('ul');
    
    if (countryButton && countryList) {
      countryButton.addEventListener('click', () => {
        const isExpanded = countryButton.getAttribute('aria-expanded') === 'true';
        countryButton.setAttribute('aria-expanded', !isExpanded);
        countryList.classList.toggle('Custom-active');
      });
      
      // Close when clicking outside
      document.addEventListener('click', (e) => {
        if (!CustomCountrySelector.contains(e.target) && countryList.classList.contains('Custom-active')) {
          countryButton.setAttribute('aria-expanded', 'false');
          countryList.classList.remove('Custom-active');
        }
      });
    }
  }
});